<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarGenerationLang extends Model
{
    //
}
