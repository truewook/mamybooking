<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PomotionGroup extends Model
{
    //
}
