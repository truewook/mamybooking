<?php
return [
	'dashboard' => 'กระดานผู้นำ',
	'back' => 'กลับ',
	'add' => 'เพิ่ม',
	'language' => 'ภาษาไทย',
	'sreach_data' => 'ค้นหา จากข้อมูลทั้งหมด ?',
	'contact' => 'ติดต่อ',
	'help' => 'ช่วยเหลือ',
	'login' => 'เข้าสู่ระบบ',
	'register' => 'สมัครสมาชิก',
	'community' => 'ชุมชน',
	'buy-sell' => 'ชื้อ-ขาย',
	'Real_Estate' => 'อสังหาริมทริพย์',
];
