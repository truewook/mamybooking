<?php
return [
	'dashboard' => 'Dashboard',
	'back' => 'back',
	'add' => 'add',
	'language' => 'English',
	'sreach_data' => 'Serach all data ?',
	'contact' => 'contact',
	'help' => 'help',
	'login' => 'login',
	'register' => 'register',
	'community' => 'community',
	'buy-sell' => 'buy-sell',
	'Real_Estate' => 'Real Estate',
];
